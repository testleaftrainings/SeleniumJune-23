package com.leaftaps.pages;

import com.framework.testng.api.base.BaseMethods;

import io.github.sukgu.Shadow;

public class WelcomePage extends BaseMethods {

	public WelcomePage clickAll() throws Exception {

		click(locateShadowElement("//div[text()='All']"));
		return this;
	}

	public IncidentsPage enterIncident() throws Exception {
		clearAndType(locateShadowElement("//input[@id='filter']"), "Incident");
		click(locateShadowElement("//mark[@class='filter-match']"));
		return new IncidentsPage();
	}

}
