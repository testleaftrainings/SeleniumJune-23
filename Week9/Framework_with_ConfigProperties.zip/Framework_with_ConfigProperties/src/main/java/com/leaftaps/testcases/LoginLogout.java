package com.leaftaps.testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.testng.api.base.BaseMethods;
import com.leaftaps.pages.Loginpage;

public class LoginLogout extends BaseMethods {
	
	@BeforeTest
	public void setfileName() {
		excelFileName="credentials";
		testcaseName="LoginLogout";
		testDescription ="Functionality of LoginLogout";
		authors="Hari";
		category="Funtional";
	
	}
	
	
	@Test(dataProvider="fetchData")
	public void runLoginLogout(String uname,String pwd) throws IOException {	
	 new Loginpage()
	.enterUsername(uname)
	.enterPassword(pwd)
	.clickLogin();

	}
	}

