package base;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class BaseClass extends AbstractTestNGCucumberTests{

	private static final ThreadLocal<ChromeDriver>  rd = new ThreadLocal<>();
	public String excelFileName,sheetName;

	public void setDriver() {
		rd.set(new ChromeDriver() );

	}

	public RemoteWebDriver getDriver() {
		return rd.get();

	}


	@BeforeMethod
	public void preCondition() {
		setDriver();
		getDriver().get("http://leaftaps.com/opentaps/control/login");
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

	}

	@AfterMethod
	public void postCondition() {
		getDriver().close();
	}

	@DataProvider(indices=1)
	public String[][] sendData() throws IOException {
		return ReadExcel.readExcelData(excelFileName,sheetName);

	}

}
