package com.leaftaps.pages;

import com.framework.data.dynamic.FakerDataFactory;
import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.BaseMethods;

public class IncidentsPage extends BaseMethods {

	public IncidentsPage clickNewOption() throws Exception {

		switchToFrame(locateShadowElement("//iframe[@title='Main Content']"));
		click(locateElement(Locators.XPATH, "//button[text()='New']"));
		verifyExactAttribute(locateElement(Locators.XPATH, "//input[@id='incident.number']"), "value", "INC0010043");
		return this;
	}

	public IncidentsPage enterShortDescription() {
		String companyName = FakerDataFactory.getCompanyName();
		clearAndType(locateElement(Locators.ID, "incident.short_description"), companyName);
		return this;

	}

	public VerifyIncidentPage clickSubmitButton() {
		click(locateElement(Locators.XPATH, "//button[text()='Submit']"));
		defaultContent();
		return new VerifyIncidentPage();

	}

}
