package testcases;

import base.BaseClass;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features="src/main/java/features/TC_002CreateLead.feature",
                 glue="pages",
                 monochrome=true,
                 publish=true)
public class CucumberRunner extends BaseClass{

	
}
