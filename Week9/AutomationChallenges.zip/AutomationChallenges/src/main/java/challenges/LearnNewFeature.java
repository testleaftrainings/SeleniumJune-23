package challenges;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;
import static org.openqa.selenium.support.locators.RelativeLocator.*;

import java.time.Duration;

public class LearnNewFeature {

	public static void main(String[] args) {

		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();

		driver.manage().window().minimize();
		driver.manage().window().fullscreen();

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

		driver.get("http://leaftaps.com/opentaps/control/main");
		driver.findElement(By.id("username")).sendKeys("Demosalesmanager");
		driver.executeScript("window.scrollTo(0, document.body.scrollHeight)");

		/*
		 * //driver.findElement(with(By.tagName("input")).below(By.id("username"))).
		 * sendKeys("crmsfa");
		 * driver.findElement(with(By.tagName("input")).near(By.id("username"))).
		 * sendKeys("crmsfa");
		 * 
		 * driver.switchTo().newWindow(WindowType.TAB).get("https://www.facebook.com/");
		 * 
		 * System.out.println(driver.getTitle());
		 * 
		 * // toRightOf // toLeftOf // above // below // near
		 * 
		 * 
		 * driver.switchTo().newWindow(WindowType.TAB);
		 * 
		 * driver.get("https://www.google.com/");
		 * driver.findElement(By.name("q")).sendKeys("leafground", Keys.ENTER);
		 * 
		 * driver.findElement(By.xpath("//cite[text()='https://www.leafground.com']")).
		 * click(); driver.findElement(with(By.tagName("i"))
		 * .below(By.xpath("//li[@id='menuform:j_idt39']//a"))).click();
		 * driver.findElement(with(By.tagName("i"))
		 * .above(By.xpath("//span[text()='Dropdown']"))).click();
		 * 
		 * String text = driver.findElement(with(By.tagName("span"))
		 * .toRightOf(By.xpath("//span[text()='Click']"))).getText();
		 * 
		 * System.out.println(text);
		 */
	}

}
