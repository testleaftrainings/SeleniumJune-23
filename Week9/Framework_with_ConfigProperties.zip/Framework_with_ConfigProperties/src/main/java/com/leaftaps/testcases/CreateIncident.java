package com.leaftaps.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.testng.api.base.BaseMethods;
import com.leaftaps.pages.Loginpage;

public class CreateIncident extends BaseMethods{
	

	@BeforeTest()
	public void setfileName() {
		excelFileName="Createleaddata";
		testcaseName="CreateLead";
		testDescription ="Test data with mandatory Field";
		authors="Hari";
		category="Funtional";
	
	}
	
	@Test(dataProvider="fetchData")
	public void runCreateincident(String uname,String pwd) throws Exception {
		
		new Loginpage()
		.enterUsername(uname)
		.enterPassword(pwd)
		.clickLogin()
		.clickAll()
		.enterIncident()
		.clickNewOption()
		.enterShortDescription()
		.clickSubmitButton()
		.getTheIncident()
		.verifyIncidentNumber();
		
		
	}
	

}
